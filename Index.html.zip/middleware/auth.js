const jwt = require('jsonwebtoken');
const { SECRET } = require('../config');
exports.requireAuth = (req, res, next) => {
  try { req.uid = jwt.verify(req.cookies.token, SECRET).uid; next(); }
  catch (e) { res.status(401).json({ error: 'Please sign in' }); }
};
