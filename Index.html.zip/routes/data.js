// Authorised document API used by the blog: posts, likes, views, comments, profiles, bookmarks.
const router = require('express').Router();
const sanitizeHtml = require('sanitize-html');
const store = require('../store'), { requireAuth } = require('../middleware/auth');
router.use(requireAuth);

const OK = /^[A-Za-z0-9_\-.~:@+\/]{1,200}$/;
const split = p => { const i = p.lastIndexOf('/'); return [p.slice(0, i), p.slice(i + 1)]; };
const cleanHtml = h => sanitizeHtml(String(h || ''), {
  allowedTags: ['p','br','b','strong','i','em','u','h1','h2','h3','ul','ol','li','a','img','blockquote','span','div','font','pre','code'],
  allowedAttributes: { a: ['href', 'target', 'rel'], img: ['src', 'alt'], font: ['size', 'face'], '*': ['style'] },
  allowedSchemes: ['http', 'https', 'mailto'], allowedSchemesByTag: { img: ['http', 'https', 'data'] },
  allowedStyles: { '*': { 'text-align': [/^(left|right|center|justify)$/], 'font-size': [/^[\d.]+(px|em|rem|%)$/], 'font-family': [/^[\w\s,'"-]+$/] } },
  transformTags: { a: sanitizeHtml.simpleTransform('a', { target: '_blank', rel: 'noopener noreferrer' }) }
});

function visible(p, d, uid) {
  if (/^(accounts|emails)\//.test(p)) return false;
  if (p.startsWith('data/users/') && !p.startsWith('data/users/' + uid + '/')) return false;
  if (p.startsWith('posts/') && d.status !== 'published' && d.author !== uid) return false;
  return true;
}
const E = (error, status = 400) => ({ error, status });

function build(col, id, body, old, uid) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return E('Invalid body');
  if (col === 'posts') {
    if (old && old.author !== uid) return E('This is not your post', 403);
    const title = String(body.title || '').trim();
    if (title.length < 3 || title.length > 150) return E('Title must be 3–150 characters');
    if (!['draft', 'published'].includes(body.status)) return E('Invalid status');
    const cover = String(body.cover || '');
    if (cover.length > 400000 || (cover && !/^(data:image\/|https?:)/.test(cover))) return E('Invalid cover image');
    const tags = (Array.isArray(body.tags) ? body.tags : []).slice(0, 8).map(t => String(t).trim().slice(0, 30)).filter(Boolean);
    return { data: { title, desc: String(body.desc || '').trim().slice(0, 300), content: cleanHtml(body.content), cover,
      category: String(body.category || 'Technology').slice(0, 40), tags, status: body.status, author: uid,
      createdAt: old ? old.createdAt : Date.now(), updatedAt: Date.now() } };
  }
  if (col === 'likes' || col === 'views') {
    const post = String(body.post || '');
    if (id !== post + '_' + uid || !store.has('posts/' + post)) return E('Forbidden', 403);
    return { data: { post, user: uid } };
  }
  if (col === 'comments') {
    if (old) return E('Comments cannot be edited', 403);
    const text = String(body.text || '').trim(), post = String(body.post || '');
    if (!text || text.length > 1000) return E('Comment must be 1–1000 characters');
    if (!store.has('posts/' + post)) return E('Post not found', 404);
    return { data: { post, user: uid, text, createdAt: Date.now() } };
  }
  if (col === 'profiles') {
    if (id !== uid || !old) return E('Forbidden', 403);
    const fullName = String(body.fullName || '').trim().slice(0, 60);
    if (fullName.length < 2) return E('Enter your full name');
    return { data: { ...old, fullName } };
  }
  if (col.startsWith('data/users/' + uid + '/')) {
    if (JSON.stringify(body).length > 5000) return E('Too large');
    return { data: body };
  }
  return E('Forbidden', 403);
}
function pathOf(req, res) {
  const p = String(req.query.path || '');
  if (!OK.test(p) || p.includes('..') || p.startsWith('/') || p.endsWith('/')) { res.status(400).json({ error: 'Bad path' }); return null; }
  return p;
}
router.get('/collection', (req, res) => {
  const c = pathOf(req, res); if (!c) return;
  res.json({ docs: store.list(c).filter(d => visible(c + '/' + d.id, d.data, req.uid)) });
});
router.get('/doc', (req, res) => {
  const p = pathOf(req, res); if (!p) return;
  const d = store.get(p);
  if (d === undefined || !visible(p, d, req.uid)) return res.status(404).json({ error: 'Not found' });
  res.json({ data: d });
});
function write(req, res, merge) {
  const p = pathOf(req, res); if (!p) return;
  const [col, id] = split(p), old = store.get(p);
  if (merge && !old) return res.status(404).json({ error: 'Not found' });
  const r = build(col, id, merge ? { ...old, ...req.body } : req.body, old, req.uid);
  if (r.error) return res.status(r.status).json({ error: r.error });
  store.set(p, r.data);
  res.json({ data: r.data });
}
router.put('/doc', (req, res) => write(req, res, false));
router.patch('/doc', (req, res) => write(req, res, true));
router.delete('/doc', (req, res) => {
  const p = pathOf(req, res); if (!p) return;
  const [col, id] = split(p), old = store.get(p);
  if (!old) return res.json({ deleted: false });
  let ok = false;
  if (col === 'posts') ok = old.author === req.uid;
  else if (col === 'likes' || col === 'views') ok = id.endsWith('_' + req.uid);
  else if (col === 'comments') ok = old.user === req.uid || (store.get('posts/' + old.post) || {}).author === req.uid;
  else ok = col.startsWith('data/users/' + req.uid + '/');
  if (!ok) return res.status(403).json({ error: 'Forbidden' });
  store.del(p);
  if (col === 'posts') store.purgePost(id);
  res.json({ deleted: true });
});
module.exports = router;
