const router = require('express').Router();
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), rateLimit = require('express-rate-limit');
const store = require('../store'), { SECRET, cookieOpts } = require('../config'), { requireAuth } = require('../middleware/auth');

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, message: { error: 'Too many attempts. Try again in a few minutes.' } });
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const pub = u => ({ id: u, fullName: store.get('profiles/' + u).fullName });
function login(res, uid, remember) {
  const days = remember ? 30 : 1;
  const token = jwt.sign({ uid }, SECRET, { expiresIn: days + 'd' });
  res.cookie('token', token, remember ? { ...cookieOpts, maxAge: days * 864e5 } : cookieOpts);
}

// POST /api/auth/signup
router.post('/signup', limiter, async (req, res, next) => {
  try {
    const b = req.body || {};
    const fn = String(b.fullName || '').trim(), em = String(b.email || '').trim().toLowerCase(), un = String(b.username || '').trim().toLowerCase(), pw = String(b.password || '');
    if (fn.length < 2 || fn.length > 60) return bad(res, 'Enter your full name');
    if (!/^[a-z0-9_.+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/.test(em)) return bad(res, 'Enter a valid email');
    if (!/^[a-z0-9_]{3,20}$/.test(un)) return bad(res, 'Username: 3–20 letters, numbers or underscores');
    if (pw.length < 8 || pw.length > 100) return bad(res, 'Password needs 8+ characters');
    if (store.has('accounts/' + un)) return bad(res, 'Username already taken', 409);
    if (store.has('emails/' + em)) return bad(res, 'Email already registered', 409);
    const hash = await bcrypt.hash(pw, 10);
    store.set('accounts/' + un, { hash, email: em });
    store.set('emails/' + em, { un });
    store.set('profiles/' + un, { fullName: fn, createdAt: Date.now() });
    login(res, un, true);
    res.status(201).json({ user: pub(un) });
  } catch (e) { next(e); }
});

// POST /api/auth/signin  (email or username)
router.post('/signin', limiter, async (req, res, next) => {
  try {
    const b = req.body || {};
    let id = String(b.identifier || '').trim().toLowerCase();
    if (id.includes('@')) id = (store.get('emails/' + id) || {}).un || '';
    const acc = id && store.get('accounts/' + id);
    const ok = acc && await bcrypt.compare(String(b.password || ''), acc.hash);
    if (!ok) return bad(res, 'Invalid credentials', 401);
    login(res, id, !!b.remember);
    res.json({ user: pub(id) });
  } catch (e) { next(e); }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => { res.clearCookie('token', cookieOpts); res.json({ message: 'Logged out' }); });

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  if (!store.get('profiles/' + req.uid)) return bad(res, 'Account not found', 401);
  res.json({ user: pub(req.uid) });
});

// PUT /api/auth/password
router.put('/password', requireAuth, async (req, res, next) => {
  try {
    const { current = '', next: np = '' } = req.body || {};
    const acc = store.get('accounts/' + req.uid);
    if (!acc || !(await bcrypt.compare(String(current), acc.hash))) return bad(res, 'Current password is wrong', 401);
    if (String(np).length < 8 || String(np).length > 100) return bad(res, 'New password needs 8+ characters');
    store.set('accounts/' + req.uid, { ...acc, hash: await bcrypt.hash(String(np), 10) });
    res.json({ message: 'Password changed' });
  } catch (e) { next(e); }
});
module.exports = router;
