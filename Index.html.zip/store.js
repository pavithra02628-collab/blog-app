// Tiny JSON-file document store (no database install needed). Swap for MongoDB later.
const fs = require('fs'), path = require('path');
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const FILE = path.join(DIR, 'db.json');
let mem;
try { mem = JSON.parse(fs.readFileSync(FILE, 'utf8')); }
catch (e) { try { mem = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'seed.json'), 'utf8')); } catch (e2) { mem = {}; } }
let timer;
function save() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    try { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(mem)); }
    catch (e) { console.error('Could not save data:', e.message); }
  }, 50);
}
module.exports = {
  has: p => p in mem,
  get: p => mem[p],
  set: (p, d) => { mem[p] = d; save(); },
  del: p => { delete mem[p]; save(); },
  list: c => Object.keys(mem).filter(k => k.startsWith(c + '/') && !k.slice(c.length + 1).includes('/')).map(k => ({ id: k.slice(c.length + 1), data: mem[k] })),
  purgePost: id => { Object.keys(mem).forEach(k => { if (/^(likes|views|comments)\//.test(k) && mem[k].post === id) delete mem[k]; }); save(); }
};
