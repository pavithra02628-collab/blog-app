const crypto = require('crypto');
const PROD = process.env.NODE_ENV === 'production';
let SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  if (PROD) { console.error('JWT_SECRET is required in production'); process.exit(1); }
  SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('JWT_SECRET not set: using a temporary secret (logins reset when the server restarts)');
}
module.exports = {
  PROD, SECRET, PORT: process.env.PORT || 3000,
  // HTTP-only cookie. SameSite=None + Secure in production so a separately hosted frontend can use it.
  cookieOpts: { httpOnly: true, sameSite: PROD ? 'none' : 'lax', secure: PROD, path: '/' }
};
