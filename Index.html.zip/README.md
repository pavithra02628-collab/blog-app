# Inkwell – Node.js + Express backend

REST API (sign up, sign in, log out, posts, comments, likes, bookmarks) plus the Inkwell frontend, served from the same server.

## Run on your computer
1. Install Node.js 18+ from nodejs.org.
2. In this folder run: `npm install`
3. Copy `.env.example` to `.env` and set `JWT_SECRET` to a long random text.
4. Run: `npm start`, then open http://localhost:3000

## API
| Method | Endpoint | What it does |
|---|---|---|
| POST | /api/auth/signup | Create account (fullName, email, username, password) and sign in |
| POST | /api/auth/signin | Sign in with identifier (email or username), password, remember |
| POST | /api/auth/logout | Clear the login cookie |
| GET | /api/auth/me | Current user (needs login) |
| PUT | /api/auth/password | Change password (current, next) |
| GET | /api/data/collection?path=posts | List documents (posts, likes, views, comments, profiles, ...) |
| GET / PUT / PATCH / DELETE | /api/data/doc?path=posts/ID | Read, create/replace, update or delete one document, with owner checks |
| GET | /api/health | Server check |

Passwords are hashed with bcrypt. The login is a JWT in an HTTP-only cookie. Post HTML is sanitised on the server. Sign in is rate limited.

## Deploy on Render (works from a phone browser)
1. Put this whole folder in a GitHub repository.
2. On render.com choose New, then Web Service, and connect the repository.
3. Build command `npm install`, start command `npm start`.
4. Add environment variables: `NODE_ENV=production` and `JWT_SECRET=` (a long random text).
5. Deploy. Open the address Render gives you. The site and API run together.

## Notes
- Data is stored in `data/db.json`. On Render's free plan this file is erased when the server restarts, so use MongoDB for permanent data.
- If the frontend stays on GitHub Pages, set the backend address in `public/js/config.js` and `CLIENT_ORIGIN` on the server. Some phone browsers (Safari) block cross-site cookies, so serving everything from the backend is more reliable.
