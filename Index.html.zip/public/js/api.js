/* Talks to the Express backend. Gives the app the same db interface it used before. */
(function () {
  const BASE = (window.INKWELL_API_URL || '').replace(/\/$/, '') + '/api';
  async function call(method, url, body) {
    let r;
    try { r = await fetch(BASE + url, { method, credentials: 'include', headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined }); }
    catch (e) { throw new Error('Cannot reach the server'); }
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) { const err = new Error(j.error || 'Request failed'); err.status = r.status; throw err; }
    return j;
  }
  window.api = { get: u => call('GET', u), post: (u, b) => call('POST', u, b || {}), put: (u, b) => call('PUT', u, b) };
  const subs = new Set(), poke = () => subs.forEach(f => f());
  setInterval(() => { if (!document.hidden && subs.size) poke(); }, 5000);
  function watch(load, cb, err) {
    let dead = false, last = null;
    const run = async () => {
      try { const v = await load(); const s = JSON.stringify(v.raw); if (!dead && s !== last) { last = s; cb(v.snap); } }
      catch (e) { if (!dead && err && e.status !== 401) err(e); }
    };
    subs.add(run); run();
    return () => { dead = true; subs.delete(run); };
  }
  const q = p => '?path=' + encodeURIComponent(p);
  const idOf = p => p.slice(p.lastIndexOf('/') + 1);
  const snapOf = (p, d) => ({ id: idOf(p), exists: d != null, data: () => d == null ? undefined : JSON.parse(JSON.stringify(d)) });
  async function readDoc(p) {
    try { const j = await call('GET', '/data/doc' + q(p)); return { raw: j.data, snap: snapOf(p, j.data) }; }
    catch (e) { if (e.status === 404) return { raw: null, snap: snapOf(p, null) }; throw e; }
  }
  const docRef = p => ({
    id: idOf(p), path: p,
    get: async () => (await readDoc(p)).snap,
    set: async d => { await call('PUT', '/data/doc' + q(p), d); poke(); },
    update: async d => { await call('PATCH', '/data/doc' + q(p), d); poke(); },
    delete: async () => { await call('DELETE', '/data/doc' + q(p)); poke(); },
    onSnapshot: (cb, err) => watch(() => readDoc(p), cb, err)
  });
  const nid = () => 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  window.remoteDB = {
    doc: docRef,
    collection: c => ({
      doc: id => docRef(c + '/' + (id || nid())),
      add: async d => { const r = docRef(c + '/' + nid()); await r.set(d); return r; },
      onSnapshot: (cb, err) => watch(async () => {
        const j = await call('GET', '/data/collection' + q(c));
        return { raw: j.docs, snap: { docs: j.docs.map(x => ({ id: x.id, data: () => JSON.parse(JSON.stringify(x.data)) })) } };
      }, cb, err)
    })
  };
})();
