// Leave empty when the backend serves this site. If the frontend is hosted elsewhere
// (for example GitHub Pages), put your backend address here, e.g. 'https://inkwell-api.onrender.com'
window.INKWELL_API_URL = '';
